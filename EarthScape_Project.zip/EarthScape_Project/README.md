# Climate Change Data Pipeline (Hadoop + MongoDB + Tableau)

An end-to-end Big Data Engineering project that processes over 8 Million climate records to visualize global temperature anomalies from 1743 to modern times.

## 🛠️ Tech Stack
- **Storage & Processing:** Apache Hadoop (HDFS), Hive
- **Database:** MongoDB (NoSQL)
- **Backend Bridge:** Python (ETL Pipeline)
- **Frontend Visualization:** Tableau (Animated Dashboard)

## 🚀 How It Works
1. **Ingestion:** 8M+ rows ingest होती hain Hadoop distributed cluster par.
2. **ETL & Filter:** Python bridge script data clean karti hai aur top hottest cities filter karti hai.
3. **Database Layer:** Processed data MongoDB database mein push hota hai.
4. **BI Dashboard:** Tableau connected hai processed dataset se to show live animated map trends.