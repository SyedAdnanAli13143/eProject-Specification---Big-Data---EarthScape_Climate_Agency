from pyhive import hive
from pymongo import MongoClient
import sys

print("--- EarthScape ETL Bridge Started ---")

try:
    # 1. Hive Connection 
    # configuration parameters Windows aur WSL ke darmiyan connection ko stable banate hain
    print("Attempting to connect to Hive (Port 10000)...")
    conn = hive.Connection(
        host="localhost", 
        port=10000, 
        username="hadoop", 
        auth='NOSASL',
        configuration={
            'hive.server2.transport.mode': 'binary',
            'hive.server2.thrift.resultset.default.fetch.size': '1000'
        }
    )
    cursor = conn.cursor()
    print("[SUCCESS] Hive Connected!")

    # 2. MongoDB Connection
    print("Connecting to MongoDB Compass...")
    client = MongoClient("mongodb://localhost:27017/")
    db = client["EarthScape"]
    collection = db["hottest_cities"]
    print("[SUCCESS] MongoDB Connected!")

    # 3. Extracting Data from Hive
    print("Fetching top 500 hottest records from Hive...")
    # Humne pehle climate_cleaned table banayi thi, wahi use kar rahe hain
    cursor.execute("""
        SELECT city, country, MAX(avg_temp) as max_t 
        FROM climate_cleaned 
        GROUP BY city, country 
        ORDER BY max_t DESC 
        LIMIT 500
    """)
    rows = cursor.fetchall()

    # 4. Loading Data into MongoDB
    print(f"Moving {len(rows)} records to NoSQL Database...")
    
    # Purana data delete karein taake duplicates na hon
    collection.delete_many({}) 

    for row in rows:
        data = {
            "city": row[0],
            "country": row[1],
            "max_temperature": row[2]
        }
        collection.insert_one(data)

    print("--- ETL PROCESS COMPLETED SUCCESSFULLY! ---")
    print("Check MongoDB Compass now and Refresh.")

except Exception as e:
    print(f"\n[ERROR] : {e}")
    print("\nTip: Check  Linux terminal par 'hiveserver2' sahi se chal raha hai.")

finally:
    if 'conn' in locals():
        conn.close()